%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

int yylex(void);
void yyerror(char *s);

extern int token_line;
extern int token_col;
extern char *current_error_yytext;
extern bool emit_tokens;

bool syntax_error_found = false;

typedef struct node {
    char *type;           
    char *value;
    char *anotated_type;  
    int line;
    int col;
    struct node *child;   
    struct node *sibling; 
} Node;

Node* program_root = NULL;

Node* new_node(const char *type, const char *value, int line, int col) {
    Node *n = (Node*)malloc(sizeof(Node));
    n->type = strdup(type);
    n->value = value ? strdup(value) : NULL;
    n->anotated_type = NULL; 
    n->line = line;
    n->col = col;
    n->child = NULL;
    n->sibling = NULL;
    return n;
}

void add_sibling(Node *node, Node *sibling) {
    Node *current;
    if (node == NULL || sibling == NULL) return;
    current = node;
    while (current->sibling != NULL) {
        current = current->sibling;
    }
    current->sibling = sibling;
}

void add_child(Node *parent, Node *child) {
    if (parent == NULL || child == NULL) return;
    if (parent->child == NULL) {
        parent->child = child;
    } else {
        add_sibling(parent->child, child);
    }
}

int count_siblings(Node *node) {
    int count = 0;
    while (node != NULL) {
        count++;
        node = node->sibling;
    }
    return count;
}

Node* create_block(Node *list, int line, int col) {
    Node *block;
    int count = count_siblings(list);
    if (count == 1) return list;
    block = new_node("Block", NULL, line, col);
    add_child(block, list);
    return block;
}

void print_tree(Node *node, int dots) {
    int i;
    if (node == NULL) return;
    for (i = 0; i < dots; i++) printf(".");
    if (node->value != NULL) printf("%s(%s)", node->type, node->value);
    else printf("%s", node->type);
    
    if (node->anotated_type != NULL) printf(" - %s", node->anotated_type);
    printf("\n");
    
    print_tree(node->child, dots + 2);
    print_tree(node->sibling, dots);
}

/* ========================================================================= */
/* LÓGICA DA TABELA DE SÍMBOLOS E ERROS SEMÂNTICOS - META 3 COMPLETA         */
/* ========================================================================= */

typedef struct symbol {
    char *name;
    char *type;
    char *param_types; 
    bool is_param;
    bool is_method;
    int line;
    int col;
    struct symbol *next;
} Symbol;

typedef struct sym_table {
    char *name; 
    char *return_type;
    Symbol *first_symbol;
    struct sym_table *next;
} SymbolTable;

SymbolTable *table_head = NULL;
SymbolTable *table_tail = NULL;

char* get_type_name(char *ast_type) {
    if (!ast_type) return "undef";
    if (strcmp(ast_type, "Int") == 0) return "int";
    if (strcmp(ast_type, "Double") == 0) return "double";
    if (strcmp(ast_type, "Bool") == 0) return "boolean";
    if (strcmp(ast_type, "Void") == 0) return "void";
    if (strcmp(ast_type, "StringArray") == 0) return "String[]";
    return "undef";
}

SymbolTable* create_table(const char *name, const char* ret_type) {
    SymbolTable *t = (SymbolTable*)malloc(sizeof(SymbolTable));
    t->name = strdup(name);
    t->return_type = ret_type ? strdup(ret_type) : NULL;
    t->first_symbol = NULL;
    t->next = NULL;
    if (!table_head) { table_head = t; table_tail = t; }
    else { table_tail->next = t; table_tail = t; }
    return t;
}

void add_symbol(SymbolTable *t, const char *name, const char *type, const char *param_types, bool is_param, bool is_method, int line, int col) {
    Symbol *curr;
    Symbol *s;
    if (!t || !name || !type) return;
    
    curr = t->first_symbol;
    while (curr) {
        if (strcmp(curr->name, name) == 0) {
            if (curr->is_method == is_method) {
                if (!is_method || (is_method && curr->param_types && param_types && strcmp(curr->param_types, param_types) == 0)) {
                    printf("Line %d, col %d: Symbol %s already defined\n", line, col, name);
                    return; 
                }
            }
        }
        curr = curr->next;
    }

    if (strcmp(name, "_") == 0) {
        printf("Line %d, col %d: Symbol _ is reserved\n", line, col);
    }

    s = (Symbol*)malloc(sizeof(Symbol));
    s->name = strdup(name);
    s->type = strdup(type);
    s->param_types = param_types ? strdup(param_types) : NULL;
    s->is_param = is_param;
    s->is_method = is_method;
    s->line = line;
    s->col = col;
    s->next = NULL;
    
    if (!t->first_symbol) t->first_symbol = s;
    else {
        curr = t->first_symbol;
        while (curr->next) curr = curr->next;
        curr->next = s;
    }
}

void build_symbol_tables(Node *root) {
    Node *class_id;
    char class_table_name[4096];
    SymbolTable *global_table;
    Node *decl;

    if (!root || strcmp(root->type, "Program") != 0) return;
    class_id = root->child;
    if (!class_id || !class_id->value) return;

    sprintf(class_table_name, "Class %s", class_id->value);
    global_table = create_table(class_table_name, NULL);
    
    decl = class_id->sibling;
    while (decl) {
        if (strcmp(decl->type, "FieldDecl") == 0) {
            Node *type_node = decl->child;
            Node *id_node = type_node ? type_node->sibling : NULL;
            if (type_node && id_node && id_node->value) {
                add_symbol(global_table, id_node->value, get_type_name(type_node->type), NULL, false, false, id_node->line, id_node->col);
            }
        }
        else if (strcmp(decl->type, "MethodDecl") == 0) {
            Node *header = decl->child;
            Node *body = header ? header->sibling : NULL;
            
            if (header) {
                Node *type_node = header->child;
                Node *id_node = type_node ? type_node->sibling : NULL;
                Node *params_node = id_node ? id_node->sibling : NULL;
                
                if (type_node && id_node && id_node->value && params_node) {
                    char params_sig[4096];
                    Node *param;
                    bool first = true;
                    char full_params_sig[4096];
                    char method_table_name[4096];
                    SymbolTable *local_table;
                    
                    strcpy(params_sig, "");
                    param = params_node->child;
                    
                    while (param && param->child) {
                        if (!first) strcat(params_sig, ",");
                        strcat(params_sig, get_type_name(param->child->type));
                        first = false;
                        param = param->sibling;
                    }
                    
                    strcpy(full_params_sig, "()");
                    if (strlen(params_sig) > 0) sprintf(full_params_sig, "(%s)", params_sig);
                    
                    add_symbol(global_table, id_node->value, get_type_name(type_node->type), full_params_sig, false, true, id_node->line, id_node->col);
                    
                    sprintf(method_table_name, "Method %s(%s)", id_node->value, params_sig);
                    local_table = create_table(method_table_name, get_type_name(type_node->type));
                    
                    add_symbol(local_table, "return", get_type_name(type_node->type), NULL, false, false, 0, 0);
                    
                    param = params_node->child;
                    while (param && param->child && param->child->sibling) {
                        add_symbol(local_table, param->child->sibling->value, get_type_name(param->child->type), NULL, true, false, param->child->sibling->line, param->child->sibling->col);
                        param = param->sibling;
                    }
                    
                    if (body) {
                        Node *body_decl = body->child;
                        while (body_decl) {
                            if (strcmp(body_decl->type, "VarDecl") == 0 && body_decl->child && body_decl->child->sibling) {
                                add_symbol(local_table, body_decl->child->sibling->value, get_type_name(body_decl->child->type), NULL, false, false, body_decl->child->sibling->line, body_decl->child->sibling->col);
                            }
                            body_decl = body_decl->sibling;
                        }
                    }
                }
            }
        }
        decl = decl->sibling;
    }
}

void print_symbol_tables() {
    SymbolTable *t = table_head;
    Symbol *s;
    while (t) {
        printf("===== %s Symbol Table =====\n", t->name);
        s = t->first_symbol;
        while (s) {
            if (s->param_types) {
                printf("%s\t%s\t%s\n", s->name, s->param_types, s->type);
            } else {
                printf("%s\t\t%s", s->name, s->type);
                if (s->is_param) printf("\tparam");
                printf("\n");
            }
            s = s->next;
        }
        printf("\n");
        t = t->next;
    }
}

char* lookup_variable_type(const char *name, SymbolTable *local, SymbolTable *global, int line, int col) {
    Symbol *s;
    if (local) {
        s = local->first_symbol;
        while (s) {
            if (strcmp(s->name, name) == 0 && !s->is_method) return s->type;
            s = s->next;
        }
    }
    if (global) {
        s = global->first_symbol;
        while (s) {
            if (strcmp(s->name, name) == 0 && !s->is_method) return s->type;
            s = s->next;
        }
    }
    printf("Line %d, col %d: Cannot find symbol %s\n", line, col, name);
    return "undef";
}

bool is_compatible(const char *expected, const char *provided) {
    if (strcmp(expected, provided) == 0) return true;
    if (strcmp(expected, "double") == 0 && strcmp(provided, "int") == 0) return true;
    return false;
}

void check_number_bounds(Node *node) {
    char clean_num[4096];
    int pos = 0;
    int i;
    if (strcmp(node->type, "Natural") == 0) {
        for (i = 0; node->value[i] != '\0'; i++) {
            if (node->value[i] != '_') clean_num[pos++] = node->value[i];
        }
        clean_num[pos] = '\0';
        
        if (strlen(clean_num) > 10) {
            printf("Line %d, col %d: Number %s out of bounds\n", node->line, node->col, node->value);
        } else if (strlen(clean_num) == 10) {
            if (strcmp(clean_num, "2147483648") > 0) {
                printf("Line %d, col %d: Number %s out of bounds\n", node->line, node->col, node->value);
            }
        }
    }
}

void annotate_tree(Node *node, SymbolTable *local_table, SymbolTable *global_table) {
    Node *decl, *header, *id_node, *params_node, *param, *child, *args;
    char params_sig[4096], method_table_name[4096], op[3], sig_copy[4096];
    char *arg_types[100], *param_types_array[100];
    char *t1, *t2, *ret_type, *token;
    SymbolTable *t;
    Symbol *match, *s;
    int arg_count, compatible_count, param_count, i;
    bool first, exact_match, is_compat;

    if (!node) return;

    if (strcmp(node->type, "Program") == 0) {
        global_table = table_head;
        decl = node->child->sibling;
        while (decl) {
            annotate_tree(decl, NULL, global_table);
            decl = decl->sibling;
        }
        return;
    }

    if (strcmp(node->type, "MethodDecl") == 0) {
        header = node->child;
        id_node = header->child->sibling;
        params_node = id_node->sibling;
        strcpy(params_sig, "");
        param = params_node->child;
        first = true;
        while (param && param->child) {
            if (!first) strcat(params_sig, ",");
            strcat(params_sig, get_type_name(param->child->type));
            first = false;
            param = param->sibling;
        }
        sprintf(method_table_name, "Method %s(%s)", id_node->value, params_sig);
        t = table_head;
        while (t) {
            if (strcmp(t->name, method_table_name) == 0) { local_table = t; break; }
            t = t->next;
        }
        if (header->sibling) annotate_tree(header->sibling, local_table, global_table);
        return;
    }

    /* Ignora nós de definição de variáveis durante a anotação para não causar confusão de tipos */
    if (strcmp(node->type, "FieldDecl") == 0 || strcmp(node->type, "VarDecl") == 0 || strcmp(node->type, "MethodHeader") == 0) {
        return;
    }

    if (strcmp(node->type, "Call") == 0) {
        id_node = node->child;
        args = id_node->sibling;
        arg_count = 0;
        while (args) {
            annotate_tree(args, local_table, global_table);
            arg_types[arg_count++] = args->anotated_type;
            args = args->sibling;
        }

        match = NULL;
        compatible_count = 0;
        s = global_table ? global_table->first_symbol : NULL;
        
        while (s) {
            if (strcmp(s->name, id_node->value) == 0 && s->is_method) {
                param_count = 0;
                exact_match = true;
                is_compat = true;
                
                if (s->param_types) strcpy(sig_copy, s->param_types);
                else strcpy(sig_copy, "()");
                
                token = strtok(sig_copy, "(),");
                while (token != NULL) {
                    param_types_array[param_count++] = token;
                    token = strtok(NULL, "(),");
                }
                
                if (param_count == arg_count) {
                    for (i = 0; i < param_count; i++) {
                        if (strcmp(param_types_array[i], arg_types[i]) != 0) exact_match = false;
                        if (!is_compatible(param_types_array[i], arg_types[i])) is_compat = false;
                    }
                    if (exact_match) { match = s; compatible_count = 1; break; }
                    if (is_compat) { match = s; compatible_count++; }
                }
            }
            s = s->next;
        }
        
        if (compatible_count == 1 && match) {
            id_node->anotated_type = strdup(match->param_types ? match->param_types : "()");
            node->anotated_type = strdup(match->type);
        } else if (compatible_count > 1) {
            printf("Line %d, col %d: Reference to method %s is ambiguous\n", id_node->line, id_node->col, id_node->value);
            id_node->anotated_type = strdup("undef");
            node->anotated_type = strdup("undef");
        } else {
            printf("Line %d, col %d: Cannot find symbol %s\n", id_node->line, id_node->col, id_node->value);
            id_node->anotated_type = strdup("undef");
            node->anotated_type = strdup("undef");
        }
        return;
    }

    child = node->child;
    while (child) {
        annotate_tree(child, local_table, global_table);
        child = child->sibling;
    }

    if (strcmp(node->type, "Natural") == 0) {
        node->anotated_type = strdup("int");
        check_number_bounds(node);
    } else if (strcmp(node->type, "Decimal") == 0) {
        node->anotated_type = strdup("double");
    } else if (strcmp(node->type, "BoolLit") == 0) {
        node->anotated_type = strdup("boolean");
    } else if (strcmp(node->type, "Identifier") == 0) {
        node->anotated_type = strdup(lookup_variable_type(node->value, local_table, global_table, node->line, node->col));
    } else if (strcmp(node->type, "Assign") == 0) {
        t1 = node->child->anotated_type;
        t2 = node->child->sibling->anotated_type;
        if (t1 && t2 && is_compatible(t1, t2) && strcmp(t1, "undef") != 0 && strcmp(t1, "String[]") != 0 && strcmp(t2, "undef") != 0) {
            node->anotated_type = strdup(t1);
        } else {
            printf("Line %d, col %d: Operator = cannot be applied to types %s, %s\n", node->line, node->col, t1?t1:"undef", t2?t2:"undef");
            node->anotated_type = strdup("undef");
        }
    } else if (strcmp(node->type, "Add") == 0 || strcmp(node->type, "Sub") == 0 || 
               strcmp(node->type, "Mul") == 0 || strcmp(node->type, "Div") == 0 || strcmp(node->type, "Mod") == 0) {
        t1 = node->child->anotated_type;
        t2 = node->child->sibling->anotated_type;
        if (t1 && t2 && (strcmp(t1, "int") == 0 || strcmp(t1, "double") == 0) && (strcmp(t2, "int") == 0 || strcmp(t2, "double") == 0)) {
            if (strcmp(t1, "double") == 0 || strcmp(t2, "double") == 0) node->anotated_type = strdup("double");
            else node->anotated_type = strdup("int");
        } else {
            if(strcmp(node->type, "Add")==0) strcpy(op, "+"); else if(strcmp(node->type, "Sub")==0) strcpy(op, "-");
            else if(strcmp(node->type, "Mul")==0) strcpy(op, "*"); else if(strcmp(node->type, "Div")==0) strcpy(op, "/");
            else strcpy(op, "%");
            printf("Line %d, col %d: Operator %s cannot be applied to types %s, %s\n", node->line, node->col, op, t1?t1:"undef", t2?t2:"undef");
            node->anotated_type = strdup("undef");
        }
    } else if (strcmp(node->type, "Plus") == 0 || strcmp(node->type, "Minus") == 0) {
        t1 = node->child->anotated_type;
        if (t1 && (strcmp(t1, "int") == 0 || strcmp(t1, "double") == 0)) {
            node->anotated_type = strdup(t1);
        } else {
            printf("Line %d, col %d: Operator %s cannot be applied to type %s\n", node->line, node->col, strcmp(node->type, "Plus")==0?"+":"-", t1?t1:"undef");
            node->anotated_type = strdup("undef");
        }
    } else if (strcmp(node->type, "And") == 0 || strcmp(node->type, "Or") == 0) {
        t1 = node->child->anotated_type; t2 = node->child->sibling->anotated_type;
        if (t1 && t2 && strcmp(t1, "boolean") == 0 && strcmp(t2, "boolean") == 0) node->anotated_type = strdup("boolean");
        else {
            printf("Line %d, col %d: Operator %s cannot be applied to types %s, %s\n", node->line, node->col, strcmp(node->type, "And")==0?"&&":"||", t1?t1:"undef", t2?t2:"undef");
            node->anotated_type = strdup("undef");
        }
    } else if (strcmp(node->type, "Not") == 0) {
        t1 = node->child->anotated_type;
        if (t1 && strcmp(t1, "boolean") == 0) node->anotated_type = strdup("boolean");
        else {
            printf("Line %d, col %d: Operator ! cannot be applied to type %s\n", node->line, node->col, t1?t1:"undef");
            node->anotated_type = strdup("undef");
        }
    } else if (strcmp(node->type, "Eq") == 0 || strcmp(node->type, "Ne") == 0) {
        t1 = node->child->anotated_type; t2 = node->child->sibling->anotated_type;
        if (t1 && t2 && ((is_compatible("double", t1) && is_compatible("double", t2)) || (strcmp(t1, "boolean") == 0 && strcmp(t2, "boolean") == 0))) {
            node->anotated_type = strdup("boolean");
        } else {
            printf("Line %d, col %d: Operator %s cannot be applied to types %s, %s\n", node->line, node->col, strcmp(node->type, "Eq")==0?"==":"!=", t1?t1:"undef", t2?t2:"undef");
            node->anotated_type = strdup("undef");
        }
    } else if (strcmp(node->type, "Gt") == 0 || strcmp(node->type, "Ge") == 0 || strcmp(node->type, "Lt") == 0 || strcmp(node->type, "Le") == 0) {
        t1 = node->child->anotated_type; t2 = node->child->sibling->anotated_type;
        if (t1 && t2 && is_compatible("double", t1) && is_compatible("double", t2)) node->anotated_type = strdup("boolean");
        else {
            if(strcmp(node->type, "Gt")==0) strcpy(op, ">"); else if(strcmp(node->type, "Ge")==0) strcpy(op, ">=");
            else if(strcmp(node->type, "Lt")==0) strcpy(op, "<"); else strcpy(op, "<=");
            printf("Line %d, col %d: Operator %s cannot be applied to types %s, %s\n", node->line, node->col, op, t1?t1:"undef", t2?t2:"undef");
            node->anotated_type = strdup("undef");
        }
    } else if (strcmp(node->type, "Xor") == 0) {
        t1 = node->child->anotated_type; t2 = node->child->sibling->anotated_type;
        if (t1 && t2 && strcmp(t1, "int") == 0 && strcmp(t2, "int") == 0) node->anotated_type = strdup("int");
        else if (t1 && t2 && strcmp(t1, "boolean") == 0 && strcmp(t2, "boolean") == 0) node->anotated_type = strdup("boolean");
        else {
            printf("Line %d, col %d: Operator ^ cannot be applied to types %s, %s\n", node->line, node->col, t1?t1:"undef", t2?t2:"undef");
            node->anotated_type = strdup("undef");
        }
    } else if (strcmp(node->type, "Lshift") == 0 || strcmp(node->type, "Rshift") == 0) {
        t1 = node->child->anotated_type; t2 = node->child->sibling->anotated_type;
        if (t1 && t2 && strcmp(t1, "int") == 0 && strcmp(t2, "int") == 0) node->anotated_type = strdup("int");
        else {
            printf("Line %d, col %d: Operator %s cannot be applied to types %s, %s\n", node->line, node->col, strcmp(node->type, "Lshift")==0?"<<":">>", t1?t1:"undef", t2?t2:"undef");
            node->anotated_type = strdup("undef");
        }
    } else if (strcmp(node->type, "Length") == 0) {
        t1 = node->child->anotated_type;
        if (t1 && strcmp(t1, "String[]") == 0) node->anotated_type = strdup("int");
        else {
            printf("Line %d, col %d: Operator .length cannot be applied to type %s\n", node->line, node->col, t1?t1:"undef");
            node->anotated_type = strdup("undef");
        }
    } else if (strcmp(node->type, "ParseArgs") == 0) {
        t1 = node->child->anotated_type; t2 = node->child->sibling->anotated_type;
        if (t1 && t2 && strcmp(t1, "String[]") == 0 && strcmp(t2, "int") == 0) node->anotated_type = strdup("int");
        else {
            printf("Line %d, col %d: Operator Integer.parseInt cannot be applied to types %s, %s\n", node->line, node->col, t1?t1:"undef", t2?t2:"undef");
            node->anotated_type = strdup("undef");
        }
    } else if (strcmp(node->type, "Print") == 0) {
        t1 = node->child->anotated_type;
        if (!t1 || (strcmp(t1, "int") != 0 && strcmp(t1, "double") != 0 && strcmp(t1, "boolean") != 0 && strcmp(t1, "String") != 0)) {
            printf("Line %d, col %d: Incompatible type %s in System.out.print statement\n", node->line, node->col, t1?t1:"undef");
        }
    } else if (strcmp(node->type, "If") == 0 || strcmp(node->type, "While") == 0) {
        t1 = node->child->anotated_type;
        if (!t1 || strcmp(t1, "boolean") != 0) {
            printf("Line %d, col %d: Incompatible type %s in %s statement\n", node->line, node->col, t1?t1:"undef", strcmp(node->type, "If")==0?"if":"while");
        }
    } else if (strcmp(node->type, "Return") == 0) {
        t1 = node->child ? node->child->anotated_type : "void";
        ret_type = local_table ? local_table->return_type : "undef";
        if (strcmp(ret_type, "void") == 0 && strcmp(t1, "void") != 0) {
            printf("Line %d, col %d: Incompatible type %s in return statement\n", node->line, node->col, t1);
        } else if (strcmp(ret_type, "void") != 0 && strcmp(t1, "void") == 0) {
            printf("Line %d, col %d: Incompatible type void in return statement\n", node->line, node->col);
        } else if (!is_compatible(ret_type, t1) && strcmp(ret_type, "void") != 0 && strcmp(t1, "void") != 0) {
            printf("Line %d, col %d: Incompatible type %s in return statement\n", node->line, node->col, t1);
        }
    } else if (strcmp(node->type, "StrLit") == 0) {
        node->anotated_type = strdup("String");
    }
}

%}

%union {
    struct {
        char *val;
        int line;
        int col;
    } token_info;
    struct node *node;
}

%token <token_info> CLASS PUBLIC STATIC INT BOOL DOUBLE VOID STRING
%token <token_info> LBRACE RBRACE LPAR RPAR LSQ RSQ
%token <token_info> COMMA SEMICOLON
%token <token_info> ASSIGN PLUS MINUS STAR DIV MOD
%token <token_info> AND OR NOT XOR LSHIFT RSHIFT
%token <token_info> EQ NE GE LE GT LT
%token <token_info> IF ELSE WHILE RETURN
%token <token_info> PRINT PARSEINT DOTLENGTH ARROW
%token <token_info> RESERVED IDENTIFIER NATURAL DECIMAL STRLIT BOOLLIT

%type <node> Program DeclList MethodDecl FieldDecl AuxIdList
%type <node> Type MethodHeader FormalParams MethodBody MethodBodyDecls
%type <node> VarDecl StatementList Statement Expr MethodInvocation ExprList Assignment ParseArgs

%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE
%right ASSIGN
%left OR
%left AND
%left XOR
%left EQ NE
%left GT GE LT LE
%left LSHIFT RSHIFT
%left PLUS MINUS
%left STAR DIV MOD
%right NOT UNARY_PLUS UNARY_MINUS

%%

Program: CLASS IDENTIFIER LBRACE DeclList RBRACE
    {
        $$ = new_node("Program", NULL, $1.line, $1.col);
        add_child($$, new_node("Identifier", $2.val, $2.line, $2.col));
        if ($4 != NULL) { add_child($$, $4); }
        program_root = $$;
    }
    ;

DeclList: /* Vazio */ { $$ = NULL; }
    | DeclList MethodDecl { if ($1 == NULL) { $$ = $2; } else { add_sibling($1, $2); $$ = $1; } }
    | DeclList FieldDecl { if ($1 == NULL) { $$ = $2; } else { add_sibling($1, $2); $$ = $1; } }
    | DeclList SEMICOLON { $$ = $1; }
    ;

MethodDecl: PUBLIC STATIC MethodHeader MethodBody
    {
        $$ = new_node("MethodDecl", NULL, $1.line, $1.col);
        add_child($$, $3); add_child($$, $4);
    }
    ;

FieldDecl: PUBLIC STATIC Type IDENTIFIER AuxIdList SEMICOLON
    {
        Node *aux; Node *last_decl; Node *next_aux; Node *new_decl;
        $$ = new_node("FieldDecl", NULL, $1.line, $1.col);
        add_child($$, $3);
        add_child($$, new_node("Identifier", $4.val, $4.line, $4.col));
        aux = $5; last_decl = $$;
        while (aux != NULL) {
            next_aux = aux->sibling; aux->sibling = NULL; 
            new_decl = new_node("FieldDecl", NULL, $1.line, $1.col);
            add_child(new_decl, new_node($3->type, NULL, $3->line, $3->col)); 
            add_child(new_decl, aux);
            add_sibling(last_decl, new_decl); last_decl = new_decl; aux = next_aux;
        }
    }
    | error SEMICOLON { $$ = NULL; }
    ;

AuxIdList: /* Vazio */ { $$ = NULL; }
    | AuxIdList COMMA IDENTIFIER 
    { 
        Node *id_node = new_node("Identifier", $3.val, $3.line, $3.col); 
        if ($1 == NULL) { $$ = id_node; } else { add_sibling($1, id_node); $$ = $1; } 
    }
    ;

Type: BOOL { $$ = new_node("Bool", NULL, $1.line, $1.col); }
    | INT { $$ = new_node("Int", NULL, $1.line, $1.col); }
    | DOUBLE { $$ = new_node("Double", NULL, $1.line, $1.col); }
    ;

MethodHeader: Type IDENTIFIER LPAR RPAR
    {
        $$ = new_node("MethodHeader", NULL, $1->line, $1->col);
        add_child($$, $1); add_child($$, new_node("Identifier", $2.val, $2.line, $2.col));
        add_child($$, new_node("MethodParams", NULL, $3.line, $3.col));
    }
    | Type IDENTIFIER LPAR FormalParams RPAR
    {
        Node *params;
        $$ = new_node("MethodHeader", NULL, $1->line, $1->col);
        add_child($$, $1); add_child($$, new_node("Identifier", $2.val, $2.line, $2.col));
        params = new_node("MethodParams", NULL, $3.line, $3.col);
        add_child(params, $4); add_child($$, params);
    }
    | VOID IDENTIFIER LPAR RPAR
    {
        $$ = new_node("MethodHeader", NULL, $1.line, $1.col);
        add_child($$, new_node("Void", NULL, $1.line, $1.col));
        add_child($$, new_node("Identifier", $2.val, $2.line, $2.col));
        add_child($$, new_node("MethodParams", NULL, $3.line, $3.col));
    }
    | VOID IDENTIFIER LPAR FormalParams RPAR
    {
        Node *params;
        $$ = new_node("MethodHeader", NULL, $1.line, $1.col);
        add_child($$, new_node("Void", NULL, $1.line, $1.col));
        add_child($$, new_node("Identifier", $2.val, $2.line, $2.col));
        params = new_node("MethodParams", NULL, $3.line, $3.col);
        add_child(params, $4); add_child($$, params);
    }
    ;

FormalParams: Type IDENTIFIER
    {
        $$ = new_node("ParamDecl", NULL, $1->line, $1->col);
        add_child($$, $1); add_child($$, new_node("Identifier", $2.val, $2.line, $2.col));
    }
    | FormalParams COMMA Type IDENTIFIER
    {
        Node *new_param = new_node("ParamDecl", NULL, $3->line, $3->col);
        add_child(new_param, $3); add_child(new_param, new_node("Identifier", $4.val, $4.line, $4.col));
        add_sibling($1, new_param); $$ = $1;
    }
    | STRING LSQ RSQ IDENTIFIER
    {
        $$ = new_node("ParamDecl", NULL, $1.line, $1.col);
        add_child($$, new_node("StringArray", NULL, $1.line, $1.col));
        add_child($$, new_node("Identifier", $4.val, $4.line, $4.col));
    }
    ;

MethodBody: LBRACE MethodBodyDecls RBRACE 
    { $$ = new_node("MethodBody", NULL, $1.line, $1.col); add_child($$, $2); }
    ;

MethodBodyDecls: /* Vazio */ { $$ = NULL; }
    | MethodBodyDecls Statement { if ($1 == NULL) { $$ = $2; } else { add_sibling($1, $2); $$ = $1; } }
    | MethodBodyDecls VarDecl { if ($1 == NULL) { $$ = $2; } else { add_sibling($1, $2); $$ = $1; } }
    ;

VarDecl: Type IDENTIFIER AuxIdList SEMICOLON 
    { 
        Node *aux; Node *last_decl; Node *next_aux; Node *new_decl;
        $$ = new_node("VarDecl", NULL, $1->line, $1->col);
        add_child($$, $1); add_child($$, new_node("Identifier", $2.val, $2.line, $2.col));
        aux = $3; last_decl = $$;
        while (aux != NULL) {
            next_aux = aux->sibling; aux->sibling = NULL; 
            new_decl = new_node("VarDecl", NULL, $1->line, $1->col);
            add_child(new_decl, new_node($1->type, NULL, $1->line, $1->col)); 
            add_child(new_decl, aux);
            add_sibling(last_decl, new_decl); last_decl = new_decl; aux = next_aux;
        }
    }
    ;

StatementList: /* Vazio */ { $$ = NULL; }
    | StatementList Statement { if ($1 == NULL) { $$ = $2; } else { add_sibling($1, $2); $$ = $1; } }
    ;

Statement: LBRACE StatementList RBRACE 
    { 
        if ($2 != NULL && count_siblings($2) > 1) { $$ = new_node("Block", NULL, $1.line, $1.col); add_child($$, $2); }
        else { $$ = $2; }
    }
    | IF LPAR Expr RPAR Statement %prec LOWER_THAN_ELSE 
    { 
        $$ = new_node("If", NULL, $1.line, $1.col); add_child($$, $3);
        add_child($$, create_block($5, 0, 0)); add_child($$, new_node("Block", NULL, 0, 0));
    }
    | IF LPAR Expr RPAR Statement ELSE Statement 
    { 
        $$ = new_node("If", NULL, $1.line, $1.col); add_child($$, $3);
        add_child($$, create_block($5, 0, 0)); add_child($$, create_block($7, 0, 0));
    }
    | WHILE LPAR Expr RPAR Statement 
    { 
        $$ = new_node("While", NULL, $1.line, $1.col); add_child($$, $3); add_child($$, create_block($5, 0, 0));
    }
    | RETURN SEMICOLON { $$ = new_node("Return", NULL, $1.line, $1.col); }
    | RETURN Expr SEMICOLON { $$ = new_node("Return", NULL, $1.line, $1.col); add_child($$, $2); }
    | MethodInvocation SEMICOLON { $$ = $1; }
    | Assignment SEMICOLON { $$ = $1; }
    | ParseArgs SEMICOLON { $$ = $1; }
    | SEMICOLON { $$ = NULL; }
    | PRINT LPAR Expr RPAR SEMICOLON { $$ = new_node("Print", NULL, $1.line, $1.col); add_child($$, $3); }
    | PRINT LPAR STRLIT RPAR SEMICOLON { $$ = new_node("Print", NULL, $1.line, $1.col); add_child($$, new_node("StrLit", $3.val, $3.line, $3.col)); }
    | error SEMICOLON { $$ = NULL; }
    ;

Expr: Expr PLUS Expr { $$ = new_node("Add", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr MINUS Expr { $$ = new_node("Sub", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr STAR Expr { $$ = new_node("Mul", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr DIV Expr { $$ = new_node("Div", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr MOD Expr { $$ = new_node("Mod", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr AND Expr { $$ = new_node("And", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr OR Expr { $$ = new_node("Or", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr XOR Expr { $$ = new_node("Xor", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr LSHIFT Expr { $$ = new_node("Lshift", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr RSHIFT Expr { $$ = new_node("Rshift", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr EQ Expr { $$ = new_node("Eq", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr GE Expr { $$ = new_node("Ge", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr GT Expr { $$ = new_node("Gt", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr LE Expr { $$ = new_node("Le", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr LT Expr { $$ = new_node("Lt", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | Expr NE Expr { $$ = new_node("Ne", NULL, $2.line, $2.col); add_child($$, $1); add_child($$, $3); }
    | MINUS Expr %prec UNARY_MINUS { $$ = new_node("Minus", NULL, $1.line, $1.col); add_child($$, $2); }
    | PLUS Expr %prec UNARY_PLUS { $$ = new_node("Plus", NULL, $1.line, $1.col); add_child($$, $2); }
    | NOT Expr { $$ = new_node("Not", NULL, $1.line, $1.col); add_child($$, $2); }
    | Assignment { $$ = $1; }
    | MethodInvocation { $$ = $1; }
    | ParseArgs { $$ = $1; }
    | IDENTIFIER { $$ = new_node("Identifier", $1.val, $1.line, $1.col); }
    | IDENTIFIER DOTLENGTH { $$ = new_node("Length", NULL, $2.line, $2.col); add_child($$, new_node("Identifier", $1.val, $1.line, $1.col)); }
    | NATURAL { $$ = new_node("Natural", $1.val, $1.line, $1.col); }
    | DECIMAL { $$ = new_node("Decimal", $1.val, $1.line, $1.col); }
    | BOOLLIT { $$ = new_node("BoolLit", $1.val, $1.line, $1.col); }
    | LPAR Expr RPAR { $$ = $2; }
    | LPAR error RPAR { $$ = NULL; }
    ;

MethodInvocation: IDENTIFIER LPAR RPAR 
                { $$ = new_node("Call", NULL, $1.line, $1.col); add_child($$, new_node("Identifier", $1.val, $1.line, $1.col)); }
                | IDENTIFIER LPAR ExprList RPAR 
                { $$ = new_node("Call", NULL, $1.line, $1.col); add_child($$, new_node("Identifier", $1.val, $1.line, $1.col)); add_child($$, $3); }
                | IDENTIFIER LPAR error RPAR { $$ = NULL; }
                ;

ExprList: Expr { $$ = $1; }
    | ExprList COMMA Expr { add_sibling($1, $3); $$ = $1; }
    ;

Assignment: IDENTIFIER ASSIGN Expr 
    { $$ = new_node("Assign", NULL, $2.line, $2.col); add_child($$, new_node("Identifier", $1.val, $1.line, $1.col)); add_child($$, $3); }
    ;

ParseArgs: PARSEINT LPAR IDENTIFIER LSQ Expr RSQ RPAR 
         { $$ = new_node("ParseArgs", NULL, $1.line, $1.col); add_child($$, new_node("Identifier", $3.val, $3.line, $3.col)); add_child($$, $5); }
         | PARSEINT LPAR error RPAR { $$ = NULL; }
         ;

%%

void yyerror(char *s) {
    syntax_error_found = true;
    printf("Line %d, col %d: %s: %s\n", token_line, token_col, s, current_error_yytext);
}

int main(int argc, char **argv) {
    bool parse_syntax = true;
    bool print_ast = false;
    bool print_symtab = false;
    bool semantic_only = false;

    if (argc > 1) {
        if (strcmp(argv[1], "-1") == 0 || strcmp(argv[1], "-l") == 0) {
            emit_tokens = true;
            parse_syntax = false;
        } else if (strcmp(argv[1], "-e1") == 0) {
            emit_tokens = false;
            parse_syntax = false;
        } else if (strcmp(argv[1], "-e2") == 0) {
            parse_syntax = true;
        } else if (strcmp(argv[1], "-t") == 0) {
            parse_syntax = true;
            print_ast = true;
        } else if (strcmp(argv[1], "-s") == 0) {
            parse_syntax = true;
            print_symtab = true;
        } else if (strcmp(argv[1], "-e3") == 0) {
            parse_syntax = true;
            semantic_only = true;
        }
    }
    
    if (parse_syntax) {
        yyparse();
        if (!syntax_error_found && program_root != NULL) {
            if (print_symtab || semantic_only) {
                build_symbol_tables(program_root);
                annotate_tree(program_root, NULL, NULL); 
                
                if (print_symtab) {
                    print_symbol_tables();
                    print_tree(program_root, 0); 
                }
            } else if (print_ast) {
                print_tree(program_root, 0);
            }
        }
    } else {
        while (yylex() != 0);
    }
    return 0;
}